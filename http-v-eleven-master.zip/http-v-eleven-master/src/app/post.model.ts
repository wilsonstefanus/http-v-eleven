export interface Post{
    title: string,
    content: string,
    id?: string
}