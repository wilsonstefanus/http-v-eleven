import { Component, OnInit, ViewChild } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Post } from './post.model';
import { PostService } from './post.service';
import { NgForm } from '@angular/forms';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  @ViewChild('updateForm') form?: NgForm;

  loadedPosts = [];
  showLoading = false;

  editID: string = "";
  editTitle: string = ""; 
  editContent: string = "";

  error = null;
  errorSub: Subscription;

  constructor(private postService: PostService) {
    this.loadedPosts = [];
  }

  ngOnInit() {
    this.errorSub = this.postService.errorHandling.subscribe(
      error => {
        this.error = error;
      }
    );
    
    this.fetchPosts();
  }

  ngOnDestroy(): void{
    this.errorSub.unsubscribe();
  }

  onCreatePost(postData: { title: string; content: string }) {
    // Send Http request
    // console.log(postData);
    // // this.http.post(this.postURL, postData).subscribe(
    // this.http.post<{name: string}>(this.postURL, postData).subscribe(
    //   (data) => {
    //     console.log(data);
    //   }
    // )

    this.showLoading = false;
    this.postService.createAndPost(postData);

  }

  onUpdatePost(elementRef: NgForm) {
    
    this.showLoading = true;
    // Send Http request
    this.postService.updatePosts(elementRef.value.formData.id, elementRef.value.formData.title, elementRef.value.formData.content)
    .subscribe(
      (data) => {
        this.showLoading = false;
        this.onFetchPosts();
      }
    );
  }

  onClickList(updateF: Post){
    //update the form
    this.editID = updateF.id;
    this.editTitle = updateF.title;
    this.editContent = updateF.content;
  }

  onFetchPosts() {
    this.fetchPosts();
    // Send Http request
  }

  onClearPosts() {
    this.showLoading = true;
    // Send Http request
    this.postService.clearPosts().subscribe(
      (data) => {
        this.showLoading = false;
        this.loadedPosts = [];
      }
    );
  }

  private fetchPosts(){
    this.showLoading = true;

    // this.http.get(this.postURL)

    // this.http.get<{[key: string] : Post}> (this.postURL)
    // .pipe(
    //   map( responseData => {
    //     // const postArray = [];
    //     const postArray: Post[] = [];
    //     for(const key in responseData){
    //       if(responseData.hasOwnProperty(key)){
    //         postArray.push({...responseData[key], id: key})
    //       }
    //     }
    //     return postArray;
    //   })
    // )
    
    this.postService.fetchPosts()
    .subscribe(
      posts => {
        // console.log(posts);
        this.showLoading = false;
        this.loadedPosts = posts;
      },
      error => {
        this.showLoading = false;
        // console.log(error);
        this.error = error;
      }      
    )
  }
}
