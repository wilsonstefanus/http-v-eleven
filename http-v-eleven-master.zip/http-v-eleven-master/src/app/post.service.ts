import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { catchError, map } from 'rxjs/operators';
import { Post } from './post.model';
import { Subject, throwError } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class PostService {

  errorHandling = new Subject<any>();
  endPointURL: string = 'https://angular-sqi-rnd-default-rtdb.asia-southeast1.firebasedatabase.app/';
  postURL: string = this.endPointURL + 'post.json';

  constructor(private http: HttpClient) { }

  //for posting data
  createAndPost(postData: Post) {
    this.http.post<{ name: string }>(this.postURL, postData).subscribe(
      (data) => {
        console.log(data);
        this.errorHandling.next(null);
      }
    ),
      (error) => {
        this.errorHandling.next(error);
      }
  }

  updatePosts(updateID: string, updateTitle: string, updateContent: string) {

    const data = {
      [updateID]: {
        content: updateContent,
        title: updateTitle
      }
    };

    return this.http.patch(this.postURL, data);
    // return this.http.put(this.postURL, --);

    // console.log("updated");
    // this.fetchPosts();
    // console.log("updated fetch");
  }

  //for fetching data
  fetchPosts() {
    let customParam = new HttpParams();
    customParam = customParam.append('print', 'pretty');
    customParam = customParam.append('custom-param', 'custom-param-value');

    return this.http.get<{ [key: string]: Post }>(this.postURL, {
      headers: new HttpHeaders({
        'custom-header': 'hello from custom header'
      }),
      params: customParam,
    })
      .pipe(
        map(responseData => {
          // const postArray = [];
          const postArray: Post[] = [];
          for (const key in responseData) {
            if (responseData.hasOwnProperty(key)) {
              postArray.push({ ...responseData[key], id: key })
            }
          }
          return postArray;
        }),
        catchError(
          errorRes => {
            return throwError(errorRes);
          }
        )
      );
  }

  clearPosts() {
    return this.http.delete(this.postURL);
  }

}
